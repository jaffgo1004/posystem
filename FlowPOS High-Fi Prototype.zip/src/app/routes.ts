import { createBrowserRouter } from 'react-router';
import { Root } from './components/Root';
import { LoginScreen } from './components/LoginScreen';
import { OrderDashboard } from './components/OrderDashboard';
import { PaymentScreen } from './components/PaymentScreen';
import { ProductManagement } from './components/ProductManagement';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: LoginScreen },
      { path: 'dashboard', Component: OrderDashboard },
      { path: 'payment', Component: PaymentScreen },
      { path: 'manager', Component: ProductManagement },
    ],
  },
]);

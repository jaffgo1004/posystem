import { useState } from 'react';
import { useNavigate } from 'react-router';
import {
  ArrowLeft, Zap, CreditCard, Banknote, QrCode,
  CheckCircle2, AlertCircle, ShoppingBag
} from 'lucide-react';
import { usePOS } from '../context/POSContext';

type PaymentMethod = 'cash' | 'card' | 'qr' | null;

export function PaymentScreen() {
  const navigate = useNavigate();
  const { cartItems, cartTotal, clearCart } = usePOS();

  const TAX_RATE = 0.08;
  const tax = cartTotal * TAX_RATE;
  const total = cartTotal + tax;

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(null);
  const [cashAmount, setCashAmount] = useState('');
  const [cashFocused, setCashFocused] = useState(false);
  const [cashError, setCashError] = useState('');
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  const cashNumeric = parseFloat(cashAmount) || 0;
  const change = cashNumeric - total;

  const isCashValid = paymentMethod !== 'cash' || (cashNumeric >= total);
  const isConfirmEnabled = paymentMethod !== null && isCashValid && !processing;

  const handleCashInput = (val: string) => {
    setCashAmount(val);
    const num = parseFloat(val) || 0;
    if (val && num < total) {
      setCashError(`Amount is $${(total - num).toFixed(2)} short`);
    } else {
      setCashError('');
    }
  };

  const handleConfirm = async () => {
    if (!isConfirmEnabled) return;
    setProcessing(true);
    await new Promise(r => setTimeout(r, 1500));
    setProcessing(false);
    setSuccess(true);
    await new Promise(r => setTimeout(r, 2000));
    clearCart();
    navigate('/dashboard');
  };

  const methodConfig = [
    {
      id: 'cash' as PaymentMethod,
      label: 'Cash',
      icon: Banknote,
      desc: 'Accept physical payment',
      color: '#22C55E',
      bg: '#F0FDF4',
      border: '#BBF7D0',
    },
    {
      id: 'card' as PaymentMethod,
      label: 'Card',
      icon: CreditCard,
      desc: 'Credit / Debit card',
      color: '#3B82F6',
      bg: '#EFF6FF',
      border: '#BFDBFE',
    },
    {
      id: 'qr' as PaymentMethod,
      label: 'QR Code',
      icon: QrCode,
      desc: 'Scan to pay',
      color: '#8B5CF6',
      bg: '#F5F3FF',
      border: '#DDD6FE',
    },
  ];

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center"
        style={{ background: '#F8F9FA' }}>
        <div className="text-center">
          <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce"
            style={{ background: '#DCFCE7' }}>
            <CheckCircle2 className="w-14 h-14" style={{ color: '#22C55E' }} />
          </div>
          <h2 style={{ fontWeight: 800, fontSize: '1.75rem', color: '#212529' }}>Payment Successful!</h2>
          <p className="mt-2" style={{ color: '#6C757D' }}>Transaction completed. Redirecting...</p>
          {paymentMethod === 'cash' && change > 0 && (
            <div className="mt-4 px-6 py-3 rounded-2xl inline-block"
              style={{ background: '#DCFCE7', border: '2px solid #86EFAC' }}>
              <p style={{ fontWeight: 700, fontSize: '1.1rem', color: '#15803D' }}>
                Change: ${change.toFixed(2)}
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#F8F9FA' }}>

      {/* Header */}
      <header className="flex items-center gap-4 px-6 py-4 shrink-0"
        style={{ background: '#fff', borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
        <button
          onClick={() => navigate('/dashboard')}
          className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors"
          style={{ background: '#F8F9FA' }}>
          <ArrowLeft className="w-5 h-5" style={{ color: '#212529' }} />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ background: '#FF6B00' }}>
            <Zap className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <span style={{ fontWeight: 800, fontSize: '1.1rem', color: '#212529' }}>
            <span style={{ color: '#FF6B00' }}>Flow</span>POS
          </span>
        </div>
        <div className="w-px h-6 mx-1" style={{ background: '#E9ECEF' }} />
        <h1 style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529' }}>Payment</h1>
      </header>

      <div className="flex-1 flex gap-0 overflow-hidden">

        {/* ── LEFT: Order Summary ─────────────────────────── */}
        <div className="flex flex-col w-full max-w-[460px] shrink-0 p-6 overflow-y-auto">
          <h2 className="mb-4" style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529' }}>
            Order Summary
          </h2>

          {/* Items */}
          <div className="space-y-2 mb-4">
            {cartItems.map(item => (
              <div key={item.cartId}
                className="flex items-center gap-3 p-3 rounded-xl bg-white"
                style={{ border: '1px solid rgba(0,0,0,0.05)' }}>
                <img src={item.product.image} alt={item.product.name}
                  className="w-12 h-12 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <p style={{ fontWeight: 600, fontSize: '0.875rem', color: '#212529' }}
                    className="truncate">{item.product.name}</p>
                  <p style={{ fontSize: '0.78rem', color: '#ADB5BD' }}>
                    {item.modifiers.iceLevel} Ice · {item.modifiers.sugarLevel} Sugar
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p style={{ fontSize: '0.78rem', color: '#6C757D' }}>x{item.quantity}</p>
                  <p style={{ fontWeight: 700, fontSize: '0.9rem', color: '#212529' }}>
                    ${(item.product.price * item.quantity).toFixed(2)}
                  </p>
                </div>
              </div>
            ))}

            {cartItems.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <ShoppingBag className="w-10 h-10 mb-3" style={{ color: '#CED4DA' }} />
                <p style={{ color: '#ADB5BD' }}>No items in cart</p>
              </div>
            )}
          </div>

          {/* Totals */}
          <div className="p-4 rounded-2xl mt-auto"
            style={{ background: '#fff', border: '1px solid rgba(0,0,0,0.05)' }}>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span style={{ fontSize: '0.875rem', color: '#6C757D' }}>Subtotal</span>
                <span style={{ fontSize: '0.875rem', color: '#212529', fontWeight: 500 }}>
                  ${cartTotal.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span style={{ fontSize: '0.875rem', color: '#6C757D' }}>Tax (8%)</span>
                <span style={{ fontSize: '0.875rem', color: '#212529', fontWeight: 500 }}>
                  ${tax.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between pt-2 mt-2"
                style={{ borderTop: '2px dashed #E9ECEF' }}>
                <span style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529' }}>Total</span>
                <span style={{ fontWeight: 800, fontSize: '1.4rem', color: '#FF6B00' }}>
                  ${total.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="w-px shrink-0 my-6" style={{ background: 'rgba(0,0,0,0.07)' }} />

        {/* ── RIGHT: Payment Methods ──────────────────────── */}
        <div className="flex-1 flex flex-col p-6 overflow-y-auto">
          <h2 className="mb-4" style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529' }}>
            Payment Method
          </h2>

          {/* Method Tiles */}
          <div className="grid gap-3 mb-5" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
            {methodConfig.map(m => {
              const Icon = m.icon;
              const isSelected = paymentMethod === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id)}
                  className="flex flex-col items-center justify-center p-5 rounded-2xl transition-all duration-200"
                  style={{
                    background: isSelected ? m.bg : '#fff',
                    border: `2px solid ${isSelected ? m.color : 'rgba(0,0,0,0.07)'}`,
                    boxShadow: isSelected ? `0 4px 16px ${m.color}25` : '0 1px 4px rgba(0,0,0,0.04)',
                    transform: isSelected ? 'scale(1.03)' : 'scale(1)',
                  }}>
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3"
                    style={{ background: isSelected ? m.color : m.bg }}>
                    <Icon className="w-7 h-7" style={{ color: isSelected ? '#fff' : m.color }} />
                  </div>
                  <span style={{
                    fontWeight: 700, fontSize: '0.95rem',
                    color: isSelected ? m.color : '#212529'
                  }}>
                    {m.label}
                  </span>
                  <span style={{ fontSize: '0.75rem', color: '#6C757D', marginTop: '4px' }}>
                    {m.desc}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Cash Input */}
          {paymentMethod === 'cash' && (
            <div className="p-4 rounded-2xl mb-5"
              style={{ background: '#fff', border: '1px solid rgba(0,0,0,0.06)' }}>
              <label className="block mb-2"
                style={{ fontWeight: 600, fontSize: '0.875rem', color: '#212529' }}>
                Cash Tendered
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2"
                  style={{ fontWeight: 600, color: '#6C757D', fontSize: '1rem' }}>$</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={cashAmount}
                  onChange={e => handleCashInput(e.target.value)}
                  onFocus={() => setCashFocused(true)}
                  onBlur={() => setCashFocused(false)}
                  placeholder={total.toFixed(2)}
                  className="w-full pl-8 pr-4 py-3 rounded-xl outline-none transition-all"
                  style={{
                    background: '#F8F9FA',
                    border: `2px solid ${cashFocused ? '#FF6B00' : cashError ? '#DC3545' : 'transparent'}`,
                    fontSize: '1rem',
                    fontWeight: 500,
                    color: '#212529',
                  }}
                />
              </div>

              {cashError && (
                <div className="flex items-center gap-1.5 mt-2">
                  <AlertCircle className="w-3.5 h-3.5" style={{ color: '#DC3545' }} />
                  <p style={{ fontSize: '0.8rem', color: '#DC3545' }}>{cashError}</p>
                </div>
              )}

              {cashNumeric >= total && cashAmount && (
                <div className="flex items-center justify-between mt-3 p-3 rounded-xl"
                  style={{ background: '#F0FDF4', border: '1px solid #BBF7D0' }}>
                  <span style={{ fontSize: '0.875rem', color: '#15803D', fontWeight: 500 }}>Change</span>
                  <span style={{ fontSize: '1.1rem', fontWeight: 700, color: '#15803D' }}>
                    ${change.toFixed(2)}
                  </span>
                </div>
              )}

              {/* Quick amount buttons */}
              <div className="mt-3">
                <p style={{ fontSize: '0.78rem', color: '#ADB5BD', marginBottom: '8px' }}>Quick amounts</p>
                <div className="flex gap-2 flex-wrap">
                  {[Math.ceil(total), Math.ceil(total / 5) * 5 + 5, Math.ceil(total / 10) * 10, Math.ceil(total / 20) * 20].filter((v, i, a) => a.indexOf(v) === i).slice(0, 4).map(amt => (
                    <button
                      key={amt}
                      onClick={() => handleCashInput(amt.toString())}
                      className="px-3 py-1.5 rounded-lg transition-all"
                      style={{
                        background: cashNumeric === amt ? '#FF6B00' : '#F8F9FA',
                        color: cashNumeric === amt ? '#fff' : '#6C757D',
                        fontSize: '0.82rem',
                        fontWeight: 500,
                        border: '1px solid transparent',
                      }}>
                      ${amt.toFixed(2)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* QR Code display */}
          {paymentMethod === 'qr' && (
            <div className="flex flex-col items-center p-6 rounded-2xl mb-5"
              style={{ background: '#fff', border: '1px solid rgba(0,0,0,0.06)' }}>
              <p className="mb-4" style={{ fontWeight: 600, color: '#212529', fontSize: '0.9rem' }}>
                Scan QR to pay ${total.toFixed(2)}
              </p>
              <div className="w-40 h-40 rounded-2xl flex items-center justify-center"
                style={{ background: '#F5F3FF', border: '3px solid #8B5CF6' }}>
                <QrCode className="w-24 h-24" style={{ color: '#8B5CF6' }} />
              </div>
              <p className="mt-3" style={{ fontSize: '0.78rem', color: '#ADB5BD' }}>
                Supports all major digital wallets
              </p>
            </div>
          )}

          {/* No method selected notice */}
          {!paymentMethod && (
            <div className="flex items-center gap-2 p-3 rounded-xl mb-4"
              style={{ background: '#FFF7F0', border: '1px solid #FFE0B2' }}>
              <AlertCircle className="w-4 h-4 shrink-0" style={{ color: '#FF6B00' }} />
              <p style={{ fontSize: '0.83rem', color: '#E65100' }}>
                Please select a payment method to continue
              </p>
            </div>
          )}

          {/* Confirm Button */}
          <button
            onClick={handleConfirm}
            disabled={!isConfirmEnabled}
            className="w-full py-4 rounded-2xl text-white flex items-center justify-center gap-2 transition-all mt-auto"
            style={{
              background: isConfirmEnabled ? '#FF6B00' : '#CED4DA',
              fontWeight: 700,
              fontSize: '1.05rem',
              boxShadow: isConfirmEnabled ? '0 4px 20px rgba(255,107,0,0.35)' : 'none',
              cursor: isConfirmEnabled ? 'pointer' : 'not-allowed',
            }}>
            {processing ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                Confirm Payment
              </>
            )}
          </button>

          {!isConfirmEnabled && !processing && (
            <p className="text-center mt-2" style={{ fontSize: '0.78rem', color: '#ADB5BD' }}>
              {!paymentMethod
                ? 'Select a payment method above'
                : 'Enter a valid cash amount'}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

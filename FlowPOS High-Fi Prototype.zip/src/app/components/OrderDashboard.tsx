import { useState } from 'react';
import { useNavigate } from 'react-router';
import {
  Zap, Wifi, WifiOff, User, LogOut, Plus, Minus, Trash2,
  ShoppingCart, X, ChevronRight, AlertTriangle
} from 'lucide-react';
import { usePOS, Modifiers } from '../context/POSContext';
import { CATEGORIES, Product } from '../data/products';

/* ─── Order Modifier Modal ─────────────────────────────────────── */
function OrderModifierModal({
  product,
  onClose,
  onAdd,
}: {
  product: Product;
  onClose: () => void;
  onAdd: (modifiers: Modifiers) => void;
}) {
  const [iceLevel, setIceLevel] = useState('Normal');
  const [sugarLevel, setSugarLevel] = useState('Normal');
  const [spicyLevel, setSpicyLevel] = useState('Normal');
  const [remark, setRemark] = useState('');
  const [qty, setQty] = useState(1);

  const iceLevels = ['No Ice', 'Less Ice', 'Normal', 'Extra Ice'];
  const sugarLevels = ['No Sugar', '25%', '50%', '75%', 'Normal', 'Extra'];
  const spicyLevels = ['Less', 'Normal', 'More'];

  const isBeverage = product.category === 'Beverages';
  const isMain = product.category === 'Mains';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden"
        style={{ border: '1px solid rgba(0,0,0,0.06)' }}>
        {/* Header */}
        <div className="relative h-48 overflow-hidden">
          <img src={product.image} alt={product.name}
            className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%)' }} />
          <button onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.9)' }}>
            <X className="w-4 h-4" style={{ color: '#212529' }} />
          </button>
          <div className="absolute bottom-4 left-4">
            <h3 className="text-white" style={{ fontWeight: 700, fontSize: '1.2rem' }}>{product.name}</h3>
            <p className="text-white opacity-80" style={{ fontSize: '0.85rem' }}>{product.description}</p>
          </div>
          <div className="absolute bottom-4 right-4">
            <span className="text-white" style={{ fontWeight: 700, fontSize: '1.3rem' }}>
              ${product.price.toFixed(2)}
            </span>
          </div>
        </div>

        <div className="p-6 overflow-y-auto" style={{ maxHeight: '60vh' }}>
          {/* Ice Level — beverages only */}
          {isBeverage && (
          <div className="mb-5">
            <h4 className="mb-3" style={{ color: '#212529', fontWeight: 600, fontSize: '0.9rem' }}>
              Ice Level
            </h4>
            <div className="flex flex-wrap gap-2">
              {iceLevels.map(level => (
                <button
                  key={level}
                  onClick={() => setIceLevel(level)}
                  className="px-3 py-2 rounded-xl transition-all duration-150"
                  style={{
                    background: iceLevel === level ? '#FF6B00' : '#F8F9FA',
                    color: iceLevel === level ? '#fff' : '#6C757D',
                    fontWeight: iceLevel === level ? 600 : 400,
                    fontSize: '0.85rem',
                    border: `2px solid ${iceLevel === level ? '#FF6B00' : 'transparent'}`,
                  }}>
                  {level}
                </button>
              ))}
            </div>
          </div>
          )}

          {/* Sugar Level — beverages only */}
          {isBeverage && (
          <div className="mb-5">
            <h4 className="mb-3" style={{ color: '#212529', fontWeight: 600, fontSize: '0.9rem' }}>
              Sugar Level
            </h4>
            <div className="flex flex-wrap gap-2">
              {sugarLevels.map(level => (
                <button
                  key={level}
                  onClick={() => setSugarLevel(level)}
                  className="px-3 py-2 rounded-xl transition-all duration-150"
                  style={{
                    background: sugarLevel === level ? '#FF6B00' : '#F8F9FA',
                    color: sugarLevel === level ? '#fff' : '#6C757D',
                    fontWeight: sugarLevel === level ? 600 : 400,
                    fontSize: '0.85rem',
                    border: `2px solid ${sugarLevel === level ? '#FF6B00' : 'transparent'}`,
                  }}>
                  {level}
                </button>
              ))}
            </div>
          </div>
          )}

          {/* Spicy Level — mains only */}
          {isMain && (
          <div className="mb-5">
            <h4 className="mb-3" style={{ color: '#212529', fontWeight: 600, fontSize: '0.9rem' }}>
              🌶️ Spicy Level
            </h4>
            <div className="flex gap-3">
              {spicyLevels.map(level => {
                const isSelected = spicyLevel === level;
                const spicyColor: Record<string, string> = { Less: '#52B788', Normal: '#FF6B00', More: '#DC3545' };
                return (
                  <button
                    key={level}
                    onClick={() => setSpicyLevel(level)}
                    className="flex-1 py-2.5 rounded-xl transition-all duration-150 flex items-center justify-center gap-1.5"
                    style={{
                      background: isSelected ? spicyColor[level] : '#F8F9FA',
                      color: isSelected ? '#fff' : '#6C757D',
                      fontWeight: isSelected ? 700 : 400,
                      fontSize: '0.875rem',
                      border: `2px solid ${isSelected ? spicyColor[level] : 'transparent'}`,
                    }}>
                    {level === 'Less' && '🌿'}
                    {level === 'Normal' && '🌶️'}
                    {level === 'More' && '🔥'}
                    {level}
                  </button>
                );
              })}
            </div>
          </div>
          )}

          {/* Remark — mains only */}
          {isMain && (
          <div className="mb-5">
            <h4 className="mb-2" style={{ color: '#212529', fontWeight: 600, fontSize: '0.9rem' }}>
              Special Request
            </h4>
            <textarea
              value={remark}
              onChange={e => setRemark(e.target.value)}
              placeholder="e.g. No onion, extra sauce, allergy note…"
              rows={2}
              className="w-full rounded-xl px-3 py-2.5 resize-none outline-none transition-all"
              style={{
                background: '#F8F9FA',
                border: '2px solid transparent',
                fontSize: '0.875rem',
                color: '#212529',
                lineHeight: 1.5,
              }}
              onFocus={e => (e.currentTarget.style.border = '2px solid #FF6B00')}
              onBlur={e => (e.currentTarget.style.border = '2px solid transparent')}
            />
          </div>
          )}

          {/* Quantity + Add */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 rounded-xl p-1"
              style={{ background: '#F8F9FA' }}>
              <button
                onClick={() => setQty(q => Math.max(1, q - 1))}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition-colors"
                style={{ background: qty > 1 ? '#FF6B00' : '#E9ECEF', color: qty > 1 ? '#fff' : '#ADB5BD' }}>
                <Minus className="w-4 h-4" />
              </button>
              <span style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529', minWidth: '1.5rem', textAlign: 'center' }}>
                {qty}
              </span>
              <button
                onClick={() => setQty(q => q + 1)}
                className="w-9 h-9 rounded-lg flex items-center justify-center"
                style={{ background: '#FF6B00', color: '#fff' }}>
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => {
                for (let i = 0; i < qty; i++) onAdd({ iceLevel, sugarLevel, spicyLevel, remark });
                onClose();
              }}
              className="flex-1 py-3 rounded-xl text-white flex items-center justify-center gap-2 transition-all"
              style={{ background: '#FF6B00', fontWeight: 600, boxShadow: '0 4px 12px rgba(255,107,0,0.3)' }}>
              <ShoppingCart className="w-4 h-4" />
              Add to Cart · ${(product.price * qty).toFixed(2)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Offline Alert Modal ──────────────────────────────────────── */
function OfflineAlertModal({ onRetry, onContinue }: { onRetry: () => void; onContinue: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-sm text-center"
        style={{ border: '1px solid rgba(0,0,0,0.06)' }}>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
          style={{ background: '#FFF3CD' }}>
          <AlertTriangle className="w-8 h-8" style={{ color: '#FFC107' }} />
        </div>
        <h3 style={{ color: '#212529', fontWeight: 700, fontSize: '1.2rem' }}>
          Connection Lost
        </h3>
        <p className="mt-2 mb-6" style={{ color: '#6C757D', fontSize: '0.9rem', lineHeight: 1.6 }}>
          Unable to reach the server. Orders will be saved locally and synced when reconnected.
        </p>
        <div className="flex gap-3">
          <button
            onClick={onRetry}
            className="flex-1 py-3 rounded-xl transition-all"
            style={{
              border: '2px solid #FF6B00',
              color: '#FF6B00',
              fontWeight: 600,
              fontSize: '0.9rem',
            }}>
            Retry
          </button>
          <button
            onClick={onContinue}
            className="flex-1 py-3 rounded-xl text-white transition-all"
            style={{ background: '#FF6B00', fontWeight: 600, fontSize: '0.9rem' }}>
            Continue Offline
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Main Dashboard ───────────────────────────────────────────── */
export function OrderDashboard() {
  const navigate = useNavigate();
  const { cartItems, addToCart, updateQuantity, removeFromCart, cartTotal, cartCount, isOnline, setIsOnline, menuProducts } = usePOS();

  const [activeCategory, setActiveCategory] = useState('All');
  const [modifierProduct, setModifierProduct] = useState<Product | null>(null);
  const [showOfflineAlert, setShowOfflineAlert] = useState(false);

  const TAX_RATE = 0.08;
  const tax = cartTotal * TAX_RATE;
  const total = cartTotal + tax;

  const handleLogout = () => navigate('/');

  const handleOfflineToggle = () => {
    if (isOnline) {
      setIsOnline(false);
      setShowOfflineAlert(true);
    } else {
      setIsOnline(true);
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ background: '#F8F9FA' }}>

      {/* ── HEADER ─────────────────────────────────────────── */}
      <header className="flex items-center justify-between px-5 py-3 shrink-0"
        style={{ background: '#fff', borderBottom: '1px solid rgba(0,0,0,0.07)', height: '60px' }}>
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: '#FF6B00' }}>
            <Zap className="w-4.5 h-4.5 text-white" strokeWidth={2.5} />
          </div>
          <span style={{ fontWeight: 800, fontSize: '1.15rem', color: '#212529', letterSpacing: '-0.3px' }}>
            <span style={{ color: '#FF6B00' }}>Flow</span>POS
          </span>
        </div>

        {/* Center info */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleOfflineToggle}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all"
            style={{
              background: isOnline ? '#E8F5E9' : '#FFF3E0',
              border: `1px solid ${isOnline ? '#C8E6C9' : '#FFE0B2'}`,
            }}>
            {isOnline
              ? <Wifi className="w-3.5 h-3.5" style={{ color: '#2E7D32' }} />
              : <WifiOff className="w-3.5 h-3.5" style={{ color: '#E65100' }} />}
            <span style={{
              fontSize: '0.75rem', fontWeight: 600,
              color: isOnline ? '#2E7D32' : '#E65100'
            }}>
              {isOnline ? 'Online' : 'Offline'}
            </span>
          </button>
        </div>

        {/* Right controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl"
            style={{ background: '#F8F9FA' }}>
            <div className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: '#FF6B00' }}>
              <User className="w-4 h-4 text-white" />
            </div>
            <span style={{ fontWeight: 600, fontSize: '0.85rem', color: '#212529' }}>Admin</span>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all hover:opacity-80"
            style={{ background: '#FFF0F0', border: '1px solid #FFD1D1', color: '#DC3545' }}>
            <LogOut className="w-4 h-4" />
            <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Logout</span>
          </button>
        </div>
      </header>

      {/* ── BODY ───────────────────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">

        {/* ── LEFT: Products Area ─────────────────────────── */}
        <div className="flex flex-col flex-1 overflow-hidden">

          {/* Category Bar */}
          <div className="px-5 py-3 shrink-0" style={{ background: '#fff', borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
            <div className="flex gap-2 overflow-x-auto scrollbar-none" style={{ scrollbarWidth: 'none' }}>
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className="px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 shrink-0"
                  style={{
                    background: activeCategory === cat ? '#FF6B00' : '#F8F9FA',
                    color: activeCategory === cat ? '#fff' : '#6C757D',
                    fontWeight: activeCategory === cat ? 600 : 400,
                    fontSize: '0.875rem',
                    border: activeCategory === cat ? '2px solid #FF6B00' : '2px solid transparent',
                  }}>
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Product Grid */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))' }}>
              {(activeCategory === 'All' ? menuProducts : menuProducts.filter(p => p.category === activeCategory)).map(product => (
                <div
                  key={product.id}
                  onClick={() => {
                    if (product.category === 'Beverages' || product.category === 'Mains') {
                      setModifierProduct(product);
                    } else {
                      addToCart(product);
                    }
                  }}
                  className="bg-white rounded-2xl overflow-hidden cursor-pointer group transition-all duration-200 hover:-translate-y-0.5"
                  style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)', border: '1px solid rgba(0,0,0,0.04)' }}>
                  {/* Product Image */}
                  <div className="relative overflow-hidden" style={{ paddingTop: '75%' }}>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    {/* Quick Add button */}
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        addToCart(product);
                      }}
                      className="absolute bottom-2 right-2 w-7 h-7 rounded-full flex items-center justify-center shadow-md transition-transform hover:scale-110"
                      style={{ background: '#FF6B00' }}>
                      <Plus className="w-4 h-4 text-white" strokeWidth={2.5} />
                    </button>
                  </div>
                  {/* Product Info */}
                  <div className="p-3">
                    <p style={{ fontWeight: 600, fontSize: '0.85rem', color: '#212529', lineHeight: 1.3 }}>
                      {product.name}
                    </p>
                    <p className="mt-1" style={{ fontWeight: 700, fontSize: '0.95rem', color: '#FF6B00' }}>
                      ${product.price.toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── RIGHT: Cart Sidebar ─────────────────────────── */}
        <div className="w-72 flex flex-col shrink-0"
          style={{ background: '#fff', borderLeft: '1px solid rgba(0,0,0,0.07)' }}>

          {/* Cart Header */}
          <div className="px-4 py-4 shrink-0" style={{ borderBottom: '1px solid rgba(0,0,0,0.06)' }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" style={{ color: '#FF6B00' }} />
                <h2 style={{ fontWeight: 700, fontSize: '1rem', color: '#212529' }}>Current Order</h2>
              </div>
              {cartCount > 0 && (
                <span className="w-6 h-6 rounded-full flex items-center justify-center text-white"
                  style={{ background: '#FF6B00', fontSize: '0.75rem', fontWeight: 700 }}>
                  {cartCount}
                </span>
              )}
            </div>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-3">
            {cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full py-12">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-3"
                  style={{ background: '#F8F9FA' }}>
                  <ShoppingCart className="w-8 h-8" style={{ color: '#CED4DA' }} />
                </div>
                <p style={{ color: '#ADB5BD', fontSize: '0.875rem', fontWeight: 500 }}>Cart is empty</p>
                <p style={{ color: '#CED4DA', fontSize: '0.8rem' }}>Tap a product to add it</p>
              </div>
            ) : (
              <div className="space-y-2">
                {cartItems.map(item => (
                  <div key={item.cartId}
                    className="rounded-xl p-3 flex gap-2"
                    style={{ background: '#F8F9FA', border: '1px solid rgba(0,0,0,0.04)' }}>
                    <img src={item.product.image} alt={item.product.name}
                      className="w-12 h-12 rounded-lg object-cover shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p style={{ fontWeight: 600, fontSize: '0.82rem', color: '#212529' }}
                        className="truncate">{item.product.name}</p>
                      {item.product.category === 'Beverages' &&
                        (item.modifiers.iceLevel !== 'Normal' || item.modifiers.sugarLevel !== 'Normal') && (
                        <p style={{ fontSize: '0.7rem', color: '#ADB5BD' }}>
                          {item.modifiers.iceLevel} · {item.modifiers.sugarLevel}
                        </p>
                      )}
                      {item.product.category === 'Mains' &&
                        (item.modifiers.spicyLevel !== 'Normal' || item.modifiers.remark) && (
                        <p style={{ fontSize: '0.7rem', color: '#ADB5BD' }}>
                          {item.modifiers.spicyLevel !== 'Normal' && `🌶️ ${item.modifiers.spicyLevel}`}
                          {item.modifiers.spicyLevel !== 'Normal' && item.modifiers.remark && ' · '}
                          {item.modifiers.remark && `📝 ${item.modifiers.remark}`}
                        </p>
                      )}
                      <p style={{ fontWeight: 700, fontSize: '0.85rem', color: '#FF6B00' }}>
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </p>
                      {/* Quantity Controls */}
                      <div className="flex items-center gap-2 mt-1.5">
                        <button
                          onClick={() => updateQuantity(item.cartId, -1)}
                          className="w-6 h-6 rounded-lg flex items-center justify-center transition-colors"
                          style={{ background: '#fff', border: '1px solid #E9ECEF' }}>
                          <Minus className="w-3 h-3" style={{ color: '#6C757D' }} />
                        </button>
                        <span style={{ fontWeight: 700, fontSize: '0.85rem', color: '#212529', minWidth: '1rem', textAlign: 'center' }}>
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.cartId, 1)}
                          className="w-6 h-6 rounded-lg flex items-center justify-center"
                          style={{ background: '#FF6B00' }}>
                          <Plus className="w-3 h-3 text-white" />
                        </button>
                        <button
                          onClick={() => removeFromCart(item.cartId)}
                          className="w-6 h-6 rounded-lg flex items-center justify-center ml-auto"
                          style={{ background: '#FFF0F0' }}>
                          <Trash2 className="w-3 h-3" style={{ color: '#DC3545' }} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Cart Summary & Pay Button */}
          {cartItems.length > 0 && (
            <div className="p-4 shrink-0" style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}>
              <div className="space-y-1.5 mb-4">
                <div className="flex justify-between">
                  <span style={{ fontSize: '0.85rem', color: '#6C757D' }}>Subtotal</span>
                  <span style={{ fontSize: '0.85rem', color: '#212529', fontWeight: 500 }}>
                    ${cartTotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span style={{ fontSize: '0.85rem', color: '#6C757D' }}>Tax (8%)</span>
                  <span style={{ fontSize: '0.85rem', color: '#212529', fontWeight: 500 }}>
                    ${tax.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between pt-1.5" style={{ borderTop: '1px dashed #E9ECEF' }}>
                  <span style={{ fontSize: '0.95rem', color: '#212529', fontWeight: 700 }}>Total</span>
                  <span style={{ fontSize: '1rem', color: '#FF6B00', fontWeight: 800 }}>
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                onClick={() => navigate('/payment')}
                className="w-full py-3.5 rounded-xl text-white flex items-center justify-center gap-2 transition-all"
                style={{
                  background: '#FF6B00',
                  fontWeight: 700,
                  fontSize: '1rem',
                  boxShadow: '0 4px 15px rgba(255,107,0,0.35)',
                }}>
                Pay ${total.toFixed(2)}
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── Modifier Modal ──────────────────────────────────── */}
      {modifierProduct && (
        <OrderModifierModal
          product={modifierProduct}
          onClose={() => setModifierProduct(null)}
          onAdd={modifiers => addToCart(modifierProduct, modifiers)}
        />
      )}

      {/* ── Offline Alert Modal ─────────────────────────────── */}
      {showOfflineAlert && (
        <OfflineAlertModal
          onRetry={() => { setIsOnline(true); setShowOfflineAlert(false); }}
          onContinue={() => setShowOfflineAlert(false)}
        />
      )}
    </div>
  );
}
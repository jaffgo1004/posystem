import { Outlet } from 'react-router';
import { POSProvider } from '../context/POSContext';

export function Root() {
  return (
    <POSProvider>
      <Outlet />
    </POSProvider>
  );
}

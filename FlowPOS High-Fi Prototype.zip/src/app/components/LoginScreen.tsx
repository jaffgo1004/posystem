import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Eye, EyeOff, Zap, AlertCircle } from 'lucide-react';

export function LoginScreen() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [usernameFocused, setUsernameFocused] = useState(false);
  const [passwordFocused, setPasswordFocused] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSignIn = async () => {
    if (!username || !password) {
      setError('Please enter your username and password.');
      return;
    }
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 800));

    if (username === 'admin' && password === 'admin123') {
      navigate('/dashboard');
    } else if (username === 'manager' && password === 'manager123') {
      navigate('/manager');
    } else {
      setError('Incorrect credentials. Please try again.');
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSignIn();
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{ background: 'linear-gradient(135deg, #fff7f0 0%, #f8f9fa 50%, #fff3e8 100%)' }}
    >
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute -top-24 -right-24 w-96 h-96 rounded-full opacity-10"
          style={{ background: '#FF6B00' }}
        />
        <div
          className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full opacity-8"
          style={{ background: '#FF6B00' }}
        />
      </div>

      <div className="w-full max-w-md mx-4 relative z-10">
        {/* Logo Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 shadow-lg"
            style={{ background: '#FF6B00' }}>
            <Zap className="w-9 h-9 text-white" strokeWidth={2.5} />
          </div>
          <h1 className="text-[2rem]" style={{ color: '#212529', letterSpacing: '-0.5px' }}>
            <span style={{ color: '#FF6B00', fontWeight: 700 }}>Flow</span>
            <span style={{ fontWeight: 700 }}>POS</span>
          </h1>
          <p className="mt-1" style={{ color: '#6C757D', fontSize: '0.9rem' }}>
            Point of Sale System
          </p>
        </div>

        {/* Login Card */}
        <div
          className="bg-white p-8 rounded-2xl shadow-xl"
          style={{ border: '1px solid rgba(0,0,0,0.06)' }}
        >
          <h2 className="mb-1" style={{ color: '#212529', fontWeight: 600, fontSize: '1.25rem' }}>
            Welcome back
          </h2>
          <p className="mb-6" style={{ color: '#6C757D', fontSize: '0.875rem' }}>
            Sign in to your account to continue
          </p>

          {/* Error Message */}
          {error && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl mb-5"
              style={{ background: '#FFF0F0', border: '1px solid #FFD1D1' }}
            >
              <AlertCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#DC3545' }} />
              <p style={{ color: '#DC3545', fontSize: '0.85rem' }}>{error}</p>
            </div>
          )}

          {/* Username Field */}
          <div className="mb-4">
            <label
              className="block mb-2"
              style={{ color: '#212529', fontSize: '0.875rem', fontWeight: 500 }}
            >
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={e => setUsername(e.target.value)}
              onFocus={() => setUsernameFocused(true)}
              onBlur={() => setUsernameFocused(false)}
              onKeyDown={handleKeyDown}
              placeholder="Enter your username"
              className="w-full px-4 py-3 rounded-xl outline-none transition-all duration-200"
              style={{
                background: '#F8F9FA',
                border: `2px solid ${usernameFocused ? '#FF6B00' : 'transparent'}`,
                color: '#212529',
                fontSize: '0.9rem',
              }}
            />
          </div>

          {/* Password Field */}
          <div className="mb-6">
            <label
              className="block mb-2"
              style={{ color: '#212529', fontSize: '0.875rem', fontWeight: 500 }}
            >
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                onFocus={() => setPasswordFocused(true)}
                onBlur={() => setPasswordFocused(false)}
                onKeyDown={handleKeyDown}
                placeholder="Enter your password"
                className="w-full px-4 py-3 pr-12 rounded-xl outline-none transition-all duration-200"
                style={{
                  background: '#F8F9FA',
                  border: `2px solid ${passwordFocused ? '#FF6B00' : 'transparent'}`,
                  color: '#212529',
                  fontSize: '0.9rem',
                }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1"
                style={{ color: '#6C757D' }}
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Sign In Button */}
          <button
            onClick={handleSignIn}
            disabled={loading}
            className="w-full py-3.5 rounded-xl text-white transition-all duration-200 flex items-center justify-center gap-2"
            style={{
              background: loading ? '#FFB380' : '#FF6B00',
              fontSize: '1rem',
              fontWeight: 600,
              boxShadow: loading ? 'none' : '0 4px 15px rgba(255,107,0,0.35)',
            }}
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Signing in...
              </>
            ) : (
              'Sign In'
            )}
          </button>

          {/* Hint */}
          <div
            className="mt-5 p-3 rounded-xl text-center"
            style={{ background: '#FFF7F0', border: '1px solid #FFE5CC' }}
          >
            <p style={{ color: '#6C757D', fontSize: '0.78rem' }}>
              <span style={{ fontWeight: 600, color: '#FF6B00' }}>Staff:</span> admin / admin123
              &nbsp;·&nbsp;
              <span style={{ fontWeight: 600, color: '#FF6B00' }}>Manager:</span> manager / manager123
            </p>
          </div>
        </div>

        <p className="text-center mt-6" style={{ color: '#6C757D', fontSize: '0.8rem' }}>
          © 2026 FlowPOS · All rights reserved
        </p>
      </div>
    </div>
  );
}

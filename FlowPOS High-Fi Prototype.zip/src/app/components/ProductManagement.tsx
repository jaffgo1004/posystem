import { useState } from 'react';
import { useNavigate } from 'react-router';
import {
  Zap, LayoutDashboard, Package, ShoppingCart, BarChart2,
  Settings, LogOut, Plus, Pencil, Trash2, Search, TrendingUp,
  TrendingDown, AlertCircle, X, Check
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { Product } from '../data/products';

type NavItem = 'dashboard' | 'products' | 'orders' | 'reports' | 'settings';

type StockProduct = Product & { stock: number };

function getStockStatus(stock: number) {
  if (stock === 0) return { label: 'Out of Stock', color: '#DC3545', bg: '#FFF0F0', dot: '#DC3545' };
  if (stock <= 10) return { label: 'Low Stock', color: '#FFC107', bg: '#FFFBEB', dot: '#F59E0B' };
  return { label: 'In Stock', color: '#22C55E', bg: '#F0FDF4', dot: '#22C55E' };
}

/* ─── Edit / Add Product Modal ─────────────────────────────── */
function ProductModal({
  product,
  onClose,
  onSave,
}: {
  product: StockProduct | null;
  onClose: () => void;
  onSave: (p: StockProduct) => void;
}) {
  const isNew = product === null;
  const [name, setName] = useState(product?.name ?? '');
  const [category, setCategory] = useState(product?.category ?? 'Mains');
  const [price, setPrice] = useState(product?.price.toString() ?? '');
  const [stock, setStock] = useState(product?.stock.toString() ?? '');

  const handleSave = () => {
    if (!name || !price || !stock) return;
    onSave({
      id: product?.id ?? Date.now(),
      name, category,
      price: parseFloat(price),
      stock: parseInt(stock),
    });
    onClose();
  };

  const fieldStyle = (focused: boolean) => ({
    background: '#F8F9FA',
    border: `2px solid ${focused ? '#FF6B00' : 'transparent'}`,
    borderRadius: '12px',
    padding: '10px 14px',
    width: '100%',
    outline: 'none',
    fontSize: '0.9rem',
    color: '#212529',
  });

  const [fName, setFName] = useState(false);
  const [fPrice, setFPrice] = useState(false);
  const [fStock, setFStock] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6"
        style={{ border: '1px solid rgba(0,0,0,0.06)' }}>
        <div className="flex items-center justify-between mb-5">
          <h3 style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529' }}>
            {isNew ? 'Add New Product' : 'Edit Product'}
          </h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: '#F8F9FA' }}>
            <X className="w-4 h-4" style={{ color: '#6C757D' }} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block mb-1.5" style={{ fontSize: '0.85rem', fontWeight: 500, color: '#212529' }}>
              Product Name
            </label>
            <input value={name} onChange={e => setName(e.target.value)}
              onFocus={() => setFName(true)} onBlur={() => setFName(false)}
              placeholder="e.g. Classic Burger" style={fieldStyle(fName)} />
          </div>

          <div>
            <label className="block mb-1.5" style={{ fontSize: '0.85rem', fontWeight: 500, color: '#212529' }}>
              Category
            </label>
            <select value={category} onChange={e => setCategory(e.target.value)}
              style={{ ...fieldStyle(false), cursor: 'pointer' }}>
              {['Mains', 'Beverages', 'Desserts', 'Starters'].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block mb-1.5" style={{ fontSize: '0.85rem', fontWeight: 500, color: '#212529' }}>
                Price ($)
              </label>
              <input type="number" value={price} onChange={e => setPrice(e.target.value)}
                onFocus={() => setFPrice(true)} onBlur={() => setFPrice(false)}
                placeholder="0.00" style={fieldStyle(fPrice)} />
            </div>
            <div>
              <label className="block mb-1.5" style={{ fontSize: '0.85rem', fontWeight: 500, color: '#212529' }}>
                Stock
              </label>
              <input type="number" value={stock} onChange={e => setStock(e.target.value)}
                onFocus={() => setFStock(true)} onBlur={() => setFStock(false)}
                placeholder="0" style={fieldStyle(fStock)} />
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={onClose}
            className="flex-1 py-3 rounded-xl"
            style={{ border: '2px solid #E9ECEF', color: '#6C757D', fontWeight: 600 }}>
            Cancel
          </button>
          <button onClick={handleSave}
            className="flex-1 py-3 rounded-xl text-white flex items-center justify-center gap-2"
            style={{ background: '#FF6B00', fontWeight: 600 }}>
            <Check className="w-4 h-4" />
            {isNew ? 'Add Product' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Delete Confirm Modal ─────────────────────────────────── */
function DeleteModal({ name, onClose, onConfirm }: { name: string; onClose: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 text-center"
        style={{ border: '1px solid rgba(0,0,0,0.06)' }}>
        <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4"
          style={{ background: '#FFF0F0' }}>
          <Trash2 className="w-7 h-7" style={{ color: '#DC3545' }} />
        </div>
        <h3 style={{ fontWeight: 700, fontSize: '1.1rem', color: '#212529' }}>Delete Product?</h3>
        <p className="mt-2 mb-5" style={{ color: '#6C757D', fontSize: '0.875rem', lineHeight: 1.6 }}>
          Are you sure you want to delete <strong>{name}</strong>? This action cannot be undone.
        </p>
        <div className="flex gap-3">
          <button onClick={onClose}
            className="flex-1 py-3 rounded-xl"
            style={{ border: '2px solid #E9ECEF', color: '#6C757D', fontWeight: 600 }}>
            Cancel
          </button>
          <button onClick={onConfirm}
            className="flex-1 py-3 rounded-xl text-white"
            style={{ background: '#DC3545', fontWeight: 600 }}>
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Dashboard View ───────────────────────────────────────── */
function DashboardView({ products }: { products: StockProduct[] }) {
  const inStock = products.filter(p => p.stock > 10).length;
  const lowStock = products.filter(p => p.stock > 0 && p.stock <= 10).length;
  const outOfStock = products.filter(p => p.stock === 0).length;
  const totalValue = products.reduce((s, p) => s + p.price * p.stock, 0);

  const stats = [
    { label: 'Total Products', value: products.length.toString(), icon: Package, color: '#FF6B00', bg: '#FFF7F0' },
    { label: 'In Stock', value: inStock.toString(), icon: TrendingUp, color: '#22C55E', bg: '#F0FDF4' },
    { label: 'Low Stock', value: lowStock.toString(), icon: AlertCircle, color: '#F59E0B', bg: '#FFFBEB' },
    { label: 'Out of Stock', value: outOfStock.toString(), icon: TrendingDown, color: '#DC3545', bg: '#FFF0F0' },
  ];

  return (
    <div>
      <h2 className="mb-5" style={{ fontWeight: 700, fontSize: '1.2rem', color: '#212529' }}>
        Dashboard Overview
      </h2>
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {stats.map(s => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-2xl p-4"
              style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.04)' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: s.bg }}>
                  <Icon className="w-5 h-5" style={{ color: s.color }} />
                </div>
              </div>
              <p style={{ fontSize: '1.8rem', fontWeight: 800, color: '#212529', lineHeight: 1 }}>
                {s.value}
              </p>
              <p className="mt-1" style={{ fontSize: '0.82rem', color: '#6C757D' }}>{s.label}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-2xl p-5"
        style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.04)' }}>
        <h3 className="mb-4" style={{ fontWeight: 600, fontSize: '1rem', color: '#212529' }}>
          Inventory Value
        </h3>
        <p style={{ fontSize: '2rem', fontWeight: 800, color: '#FF6B00' }}>
          ${totalValue.toFixed(2)}
        </p>
        <p style={{ fontSize: '0.82rem', color: '#6C757D', marginTop: '4px' }}>
          Total estimated stock value across all products
        </p>
      </div>
    </div>
  );
}

/* ─── Main Product Management ──────────────────────────────────── */
export function ProductManagement() {
  const navigate = useNavigate();
  const { menuProducts, saveProduct, deleteProduct } = usePOS();
  const [activeNav, setActiveNav] = useState<NavItem>('products');
  const [search, setSearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<StockProduct | null | undefined>(undefined);
  const [deletingProduct, setDeletingProduct] = useState<StockProduct | null>(null);

  // Merge menuProducts with stock data (stock is local to manager view)
  const [stockMap, setStockMap] = useState<Record<number, number>>(() =>
    Object.fromEntries(
      [45, 8, 32, 3, 0, 18, 25, 5].map((s, i) => [i + 1, s])
    )
  );

  const products: StockProduct[] = menuProducts.map(p => ({
    ...p,
    stock: stockMap[p.id] ?? 10,
  }));

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleSaveProduct = (p: StockProduct) => {
    const { stock, ...productData } = p;
    // If new product, give it a guaranteed unique id
    const finalProduct = { ...productData, id: p.id || Date.now() };
    saveProduct(finalProduct);
    setStockMap(prev => ({ ...prev, [finalProduct.id]: stock }));
  };

  const handleDeleteProduct = (id: number) => {
    deleteProduct(id);
    setStockMap(prev => { const next = { ...prev }; delete next[id]; return next; });
    setDeletingProduct(null);
  };

  const navItems: { id: NavItem; label: string; Icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', Icon: LayoutDashboard },
    { id: 'products', label: 'Products', Icon: Package },
    { id: 'orders', label: 'Orders', Icon: ShoppingCart },
    { id: 'reports', label: 'Reports', Icon: BarChart2 },
    { id: 'settings', label: 'Settings', Icon: Settings },
  ];

  return (
    <div className="h-screen flex overflow-hidden" style={{ background: '#F8F9FA' }}>

      {/* ── SIDE NAVIGATION ─────────────────────────────── */}
      <nav className="w-56 flex flex-col shrink-0 py-5"
        style={{ background: '#fff', borderRight: '1px solid rgba(0,0,0,0.07)' }}>
        {/* Logo */}
        <div className="flex items-center gap-2 px-5 mb-8">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: '#FF6B00' }}>
            <Zap className="w-4.5 h-4.5 text-white" strokeWidth={2.5} />
          </div>
          <span style={{ fontWeight: 800, fontSize: '1.1rem', color: '#212529' }}>
            <span style={{ color: '#FF6B00' }}>Flow</span>POS
          </span>
        </div>

        {/* Manager badge */}
        <div className="mx-4 mb-5 px-3 py-2 rounded-xl"
          style={{ background: '#FFF7F0', border: '1px solid #FFE5CC' }}>
          <p style={{ fontSize: '0.72rem', color: '#FF6B00', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            Manager Portal
          </p>
          <p style={{ fontSize: '0.82rem', color: '#212529', fontWeight: 600, marginTop: '2px' }}>
            manager
          </p>
        </div>

        {/* Nav Items */}
        <div className="flex-1 px-3 space-y-1">
          {navItems.map(({ id, label, Icon }) => {
            const isActive = activeNav === id;
            return (
              <button
                key={id}
                onClick={() => setActiveNav(id)}
                className="w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-150 text-left"
                style={{
                  background: isActive ? '#FFF7F0' : 'transparent',
                  border: isActive ? '1px solid #FFE5CC' : '1px solid transparent',
                }}>
                <Icon className="w-5 h-5 shrink-0"
                  style={{ color: isActive ? '#FF6B00' : '#6C757D' }} />
                <span style={{
                  fontSize: '0.875rem',
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? '#FF6B00' : '#6C757D',
                }}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Logout */}
        <div className="px-3 pt-3" style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}>
          <button
            onClick={() => navigate('/')}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all"
            style={{ background: '#FFF0F0', border: '1px solid #FFD1D1' }}>
            <LogOut className="w-5 h-5" style={{ color: '#DC3545' }} />
            <span style={{ fontSize: '0.875rem', fontWeight: 600, color: '#DC3545' }}>
              Logout
            </span>
          </button>
        </div>
      </nav>

      {/* ── MAIN CONTENT ────────────────────────────────── */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Page Header */}
        <div className="px-6 py-4 shrink-0"
          style={{ background: '#fff', borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
          <h1 style={{ fontWeight: 700, fontSize: '1.2rem', color: '#212529' }}>
            {navItems.find(n => n.id === activeNav)?.label}
          </h1>
          <p style={{ fontSize: '0.82rem', color: '#6C757D', marginTop: '2px' }}>
            {activeNav === 'products' ? 'Manage your menu items and stock levels'
              : activeNav === 'dashboard' ? 'Overview of your store performance'
              : 'Coming soon...'}
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-6">

          {activeNav === 'dashboard' && <DashboardView products={products} />}

          {activeNav === 'products' && (
            <>
              {/* Toolbar */}
              <div className="flex items-center justify-between gap-4 mb-5">
                <div className="relative flex-1 max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
                    style={{ color: '#ADB5BD' }} />
                  <input
                    type="text"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    placeholder="Search products..."
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl outline-none transition-all"
                    style={{ background: '#fff', border: '1px solid rgba(0,0,0,0.1)', fontSize: '0.875rem', color: '#212529' }}
                  />
                </div>
                <button
                  onClick={() => setEditingProduct(null)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white transition-all"
                  style={{ background: '#FF6B00', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 3px 10px rgba(255,107,0,0.3)' }}>
                  <Plus className="w-4 h-4" />
                  Add Product
                </button>
              </div>

              {/* Products Table */}
              <div className="bg-white rounded-2xl overflow-hidden"
                style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.04)' }}>
                {/* Table Header */}
                <div className="grid px-5 py-3"
                  style={{
                    gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr',
                    borderBottom: '1px solid rgba(0,0,0,0.07)',
                    background: '#FAFAFA',
                  }}>
                  {['Product Name', 'Category', 'Price', 'Stock', 'Actions'].map(h => (
                    <span key={h} style={{ fontSize: '0.78rem', fontWeight: 600, color: '#6C757D', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                      {h}
                    </span>
                  ))}
                </div>

                {/* Table Rows */}
                {filteredProducts.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Package className="w-10 h-10 mb-3" style={{ color: '#CED4DA' }} />
                    <p style={{ color: '#ADB5BD', fontSize: '0.875rem' }}>No products found</p>
                  </div>
                ) : (
                  filteredProducts.map((product, idx) => {
                    const status = getStockStatus(product.stock);
                    return (
                      <div key={product.id}
                        className="grid px-5 py-4 items-center transition-colors hover:bg-gray-50"
                        style={{
                          gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr',
                          borderBottom: idx < filteredProducts.length - 1 ? '1px solid rgba(0,0,0,0.05)' : 'none',
                        }}>
                        {/* Name */}
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                            style={{ background: '#FFF7F0' }}>
                            <Package className="w-4 h-4" style={{ color: '#FF6B00' }} />
                          </div>
                          <span style={{ fontWeight: 600, fontSize: '0.875rem', color: '#212529' }}>
                            {product.name}
                          </span>
                        </div>
                        {/* Category */}
                        <span style={{ fontSize: '0.85rem', color: '#6C757D' }}>
                          {product.category}
                        </span>
                        {/* Price */}
                        <span style={{ fontWeight: 600, fontSize: '0.9rem', color: '#212529' }}>
                          ${product.price.toFixed(2)}
                        </span>
                        {/* Stock Badge */}
                        <div className="flex items-center gap-2">
                          <span
                            className="px-2.5 py-1 rounded-full flex items-center gap-1.5"
                            style={{ background: status.bg, fontSize: '0.78rem', fontWeight: 600, color: status.color }}>
                            <div className="w-1.5 h-1.5 rounded-full" style={{ background: status.dot }} />
                            {status.label}
                          </span>
                          <span style={{ fontSize: '0.8rem', color: '#ADB5BD' }}>
                            ({product.stock})
                          </span>
                        </div>
                        {/* Actions */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setEditingProduct(product)}
                            className="flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all hover:bg-blue-50"
                            style={{ border: '1px solid #E9ECEF' }}>
                            <Pencil className="w-3.5 h-3.5" style={{ color: '#3B82F6' }} />
                            <span style={{ fontSize: '0.65rem', color: '#3B82F6', fontWeight: 500 }}>Edit</span>
                          </button>
                          <button
                            onClick={() => setDeletingProduct(product)}
                            className="flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all hover:bg-red-50"
                            style={{ border: '1px solid #E9ECEF' }}>
                            <Trash2 className="w-3.5 h-3.5" style={{ color: '#DC3545' }} />
                            <span style={{ fontSize: '0.65rem', color: '#DC3545', fontWeight: 500 }}>Delete</span>
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Summary stats */}
              <div className="flex gap-4 mt-4">
                {[
                  { label: 'Total', count: products.length, color: '#FF6B00' },
                  { label: 'In Stock', count: products.filter(p => p.stock > 10).length, color: '#22C55E' },
                  { label: 'Low Stock', count: products.filter(p => p.stock > 0 && p.stock <= 10).length, color: '#F59E0B' },
                  { label: 'Out of Stock', count: products.filter(p => p.stock === 0).length, color: '#DC3545' },
                ].map(s => (
                  <div key={s.label} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white"
                    style={{ border: '1px solid rgba(0,0,0,0.06)' }}>
                    <div className="w-2 h-2 rounded-full" style={{ background: s.color }} />
                    <span style={{ fontSize: '0.8rem', color: '#6C757D' }}>{s.label}:</span>
                    <span style={{ fontWeight: 700, fontSize: '0.85rem', color: '#212529' }}>{s.count}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {(activeNav === 'orders' || activeNav === 'reports' || activeNav === 'settings') && (
            <div className="flex flex-col items-center justify-center h-64">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
                style={{ background: '#F8F9FA' }}>
                {activeNav === 'orders' && <ShoppingCart className="w-8 h-8" style={{ color: '#CED4DA' }} />}
                {activeNav === 'reports' && <BarChart2 className="w-8 h-8" style={{ color: '#CED4DA' }} />}
                {activeNav === 'settings' && <Settings className="w-8 h-8" style={{ color: '#CED4DA' }} />}
              </div>
              <h3 style={{ fontWeight: 600, color: '#212529' }}>Coming Soon</h3>
              <p style={{ color: '#ADB5BD', fontSize: '0.875rem', marginTop: '4px' }}>
                This section is under development
              </p>
            </div>
          )}
        </div>
      </main>

      {/* ── Modals ─────────────────────────────────────── */}
      {editingProduct !== undefined && (
        <ProductModal
          product={editingProduct}
          onClose={() => setEditingProduct(undefined)}
          onSave={handleSaveProduct}
        />
      )}

      {deletingProduct && (
        <DeleteModal
          name={deletingProduct.name}
          onClose={() => setDeletingProduct(null)}
          onConfirm={() => handleDeleteProduct(deletingProduct.id)}
        />
      )}
    </div>
  );
}
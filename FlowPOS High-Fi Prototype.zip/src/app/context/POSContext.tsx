import React, { createContext, useContext, useState, useCallback } from 'react';
import { Product, products as initialProducts } from '../data/products';

export type Modifiers = {
  iceLevel: string;
  sugarLevel: string;
  spicyLevel: string;
  remark: string;
};

export type CartItem = {
  cartId: string;
  product: Product;
  quantity: number;
  modifiers: Modifiers;
};

type POSContextType = {
  cartItems: CartItem[];
  addToCart: (product: Product, modifiers?: Modifiers) => void;
  updateQuantity: (cartId: string, delta: number) => void;
  removeFromCart: (cartId: string) => void;
  clearCart: () => void;
  isOnline: boolean;
  setIsOnline: (v: boolean) => void;
  cartTotal: number;
  cartCount: number;
  menuProducts: Product[];
  saveProduct: (p: Product) => void;
  deleteProduct: (id: number) => void;
};

const defaultModifiers: Modifiers = { iceLevel: 'Normal', sugarLevel: 'Normal', spicyLevel: 'Normal', remark: '' };

const POSContext = createContext<POSContextType | null>(null);

export function POSProvider({ children }: { children: React.ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isOnline, setIsOnline] = useState(true);
  const [menuProducts, setMenuProducts] = useState<Product[]>(initialProducts);

  const addToCart = useCallback((product: Product, modifiers: Modifiers = defaultModifiers) => {
    const cartId = `${product.id}-${modifiers.iceLevel}-${modifiers.sugarLevel}-${modifiers.spicyLevel}-${modifiers.remark}`;
    setCartItems(prev => {
      const existing = prev.find(i => i.cartId === cartId);
      if (existing) {
        return prev.map(i => i.cartId === cartId ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { cartId, product, quantity: 1, modifiers }];
    });
  }, []);

  const updateQuantity = useCallback((cartId: string, delta: number) => {
    setCartItems(prev =>
      prev.map(i => i.cartId === cartId
        ? { ...i, quantity: Math.max(0, i.quantity + delta) }
        : i
      ).filter(i => i.quantity > 0)
    );
  }, []);

  const removeFromCart = useCallback((cartId: string) => {
    setCartItems(prev => prev.filter(i => i.cartId !== cartId));
  }, []);

  const clearCart = useCallback(() => setCartItems([]), []);

  const cartTotal = cartItems.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const cartCount = cartItems.reduce((sum, i) => sum + i.quantity, 0);

  const saveProduct = useCallback((p: Product) => {
    setMenuProducts(prev => {
      const exists = prev.find(x => x.id === p.id);
      if (exists) return prev.map(x => x.id === p.id ? p : x);
      return [...prev, p];
    });
  }, []);

  const deleteProduct = useCallback((id: number) => {
    setMenuProducts(prev => prev.filter(p => p.id !== id));
  }, []);

  return (
    <POSContext.Provider value={{
      cartItems, addToCart, updateQuantity, removeFromCart, clearCart,
      isOnline, setIsOnline, cartTotal, cartCount,
      menuProducts, saveProduct, deleteProduct,
    }}>
      {children}
    </POSContext.Provider>
  );
}

export function usePOS() {
  const ctx = useContext(POSContext);
  if (!ctx) throw new Error('usePOS must be used inside POSProvider');
  return ctx;
}
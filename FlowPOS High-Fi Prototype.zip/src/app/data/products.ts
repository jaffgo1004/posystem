export type Product = {
  id: number;
  name: string;
  price: number;
  category: string;
  image: string;
  description: string;
};

export const CATEGORIES = ['All', 'Mains', 'Beverages', 'Desserts'];

export const products: Product[] = [
  {
    id: 1,
    name: "Classic Burger",
    price: 12.99,
    category: "Mains",
    image: "https://images.unsplash.com/photo-1708076158453-ad7346b6d2a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Juicy beef patty with fresh lettuce, tomato & pickles",
  },
  {
    id: 2,
    name: "Iced Coffee",
    price: 5.99,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1466689193967-9cf2e2a2b994?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Cold brew coffee with milk & ice",
  },
  {
    id: 3,
    name: "Grilled Chicken Rice",
    price: 14.99,
    category: "Mains",
    image: "https://images.unsplash.com/photo-1771074168439-0083aaac48e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Tender grilled chicken over fragrant jasmine rice",
  },
  {
    id: 4,
    name: "Bubble Tea",
    price: 6.99,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1601489310882-d2fb4451dbcc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Classic milk tea with chewy tapioca pearls",
  },
  {
    id: 5,
    name: "Pasta Carbonara",
    price: 15.99,
    category: "Mains",
    image: "https://images.unsplash.com/photo-1627207644206-a2040d60ecad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Creamy pasta with crispy pancetta & parmesan",
  },
  {
    id: 6,
    name: "Pizza Slice",
    price: 9.99,
    category: "Mains",
    image: "https://images.unsplash.com/photo-1595378833483-c995dbe4d74f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Hand-stretched dough with tomato sauce & mozzarella",
  },
  {
    id: 7,
    name: "Fresh Lemonade",
    price: 4.99,
    category: "Beverages",
    image: "https://images.unsplash.com/photo-1621263764812-ed79919f4e39?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Freshly squeezed lemon with a hint of mint",
  },
  {
    id: 8,
    name: "Chocolate Brownie",
    price: 7.99,
    category: "Desserts",
    image: "https://images.unsplash.com/photo-1654921913191-f535f8978768?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
    description: "Rich fudgy brownie served warm with vanilla cream",
  },
];

export const managerProducts = [
  { id: 1, name: "Classic Burger", category: "Mains", price: 12.99, stock: 45 },
  { id: 2, name: "Iced Coffee", category: "Beverages", price: 5.99, stock: 8 },
  { id: 3, name: "Grilled Chicken Rice", category: "Mains", price: 14.99, stock: 32 },
  { id: 4, name: "Bubble Tea", category: "Beverages", price: 6.99, stock: 3 },
  { id: 5, name: "Pasta Carbonara", category: "Mains", price: 15.99, stock: 0 },
  { id: 6, name: "Pizza Slice", category: "Mains", price: 9.99, stock: 18 },
  { id: 7, name: "Fresh Lemonade", category: "Beverages", price: 4.99, stock: 25 },
  { id: 8, name: "Chocolate Brownie", category: "Desserts", price: 7.99, stock: 5 },
];
